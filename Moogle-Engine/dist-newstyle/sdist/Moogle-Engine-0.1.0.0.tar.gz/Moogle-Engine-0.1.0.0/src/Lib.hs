module Lib
    (
      loadDocuments
    , jaccardSimilarity
    , Document
    , DocumentCollection
    , buildDictionary
    ) where

import Data.List as DL
import Data.Char
import qualified Data.Map as Map
import System.Directory
import Control.Monad
import Data.Text (Text, words, unpack)
import qualified Data.Set as Set
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import Data.Array

type Document = (String, String)
type DocumentCollection = [Document]

normalizeText :: String -> String
normalizeText = map toLower . filter (not . isPunctuation)

loadDocuments :: FilePath -> IO DocumentCollection
loadDocuments dir = do
    files <- listDirectory dir
    contents <- forM files $ \file -> do
        content <- readFile (dir ++ "/" ++ file)
        return (file, normalizeText content)
    return contents

buildDictionary :: DocumentCollection -> Set.Set String
buildDictionary documents = 
    let allWords = concatMap (DL.words . snd) documents
    in Set.fromList allWords

jaccardSimilarity :: Document -> Document -> Double
jaccardSimilarity (_, content1) (_, content2) =
    let set1 = Set.fromList $ DL.words content1
        set2 = Set.fromList $ DL.words content2
        intersectionSize = Set.size $ Set.intersection set1 set2
        unionSize = Set.size $ Set.union set1 set2
    in fromIntegral intersectionSize / fromIntegral unionSize


-- Función para calcular la distancia de Levenshtein entre dos cadenas
levenshtein :: String -> String -> Int
levenshtein s1 s2 = levMemo (length s1) (length s2)
  where
    arr = array ((0, 0), (length s1, length s2))
          [((i, j), lev i j) | i <- [0 .. length s1], j <- [0 .. length s2]]

    lev 0 j = j
    lev i 0 = i
    lev i j = minimum [ arr ! (i-1, j) + 1
                      , arr ! (i, j-1) + 1
                      , arr ! (i-1, j-1) + (if s1 !! (i-1) == s2 !! (j-1) then 0 else 1)
                      ]

    levMemo i j = arr ! (i, j)

suggestCorrection :: [Text] -> Text -> [(Text, Int)]
suggestCorrection dictionary word =
    map (\w -> (w, levenshtein (T.unpack w) (T.unpack word))) dictionary

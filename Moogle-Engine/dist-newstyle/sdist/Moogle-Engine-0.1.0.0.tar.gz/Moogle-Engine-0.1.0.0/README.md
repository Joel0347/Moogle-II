# Moogle-Engine

Trabajaremos el backend en la carpeta `src` y el frontend en al carpeta `static`.

Pasos para ejecutar el proyecto: 

1- Ir a la carpeta raíz: `cd Moogle-Engine`

2- Instalar las dependencias necesarias: `stack build`

3- Ejecutar el proyecto: `stack exec Moogle-Engine-exe`

## Nota: Para compilar el proyecto deben hacer `stack build` también antes de ejecutar.
